DUEL SYNAPSE CALCULATOR — GITHUB BUILD

This method is designed for uploading from a phone without Android Studio.

1. Upload DuelSynapseCalculator-project.zip to the ROOT of your GitHub repository.
2. Open Actions.
3. Tap "set up a workflow yourself".
4. Replace the editor contents with the contents of WORKFLOW-TO-PASTE.yml.
5. Save/commit the workflow.
6. Return to Actions. You should see "Build Duel Synapse Calculator APK".
7. Tap it, then "Run workflow".
8. Wait for the green check mark.
9. Open the completed run and download the artifact:
   Duel-Synapse-Calculator-debug-apk
10. Extract the downloaded artifact and install app-debug.apk on Android.

IMPORTANT:
- The ZIP must remain at the repository ROOT with this exact name:
  DuelSynapseCalculator-project.zip
- Do NOT upload the ZIP into a folder.
- The workflow itself must be saved at:
  .github/workflows/build-apk.yml
