# Duel Synapse Calculator — Android

Offline Android WebView package for Duel Synapse V1.0.

## Build without Android Studio

1. Create a GitHub repository.
2. Upload this entire project to the repository.
3. Open **Actions** → **Build Duel Synapse Calculator APK** → **Run workflow**.
4. After the build completes, open the workflow run and download the artifact named `Duel-Synapse-Calculator-debug-apk`.
5. Extract the ZIP and install `app-debug.apk` on your Android phone.

The HTML is bundled into `app/src/main/assets/index.html`, so the app does not require a website connection to run.
